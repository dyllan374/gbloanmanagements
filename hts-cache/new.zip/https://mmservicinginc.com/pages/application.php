<!DOCTYPE htmlMM Servicing Inc.
<html lang="en">


<!-- Mirrored from mmservicinginc.com/pages/application.php by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 17 Jan 2024 05:35:23 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="With MM Servicing Inc., you can quickly and confidently receive a line of credit decision for your business in minutes. You can draw funds anytime if approved. Apply now.">


    <link rel="shortcut icon" type="image/x-icon" href="../assets/images/png/favicon.png" />
    <!-- Libs CSS -->

    <link rel="stylesheet" href="../assets/libs/bootstrap-icons/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../assets/libs/tiny-slider/dist/tiny-slider.css">
    <link rel="stylesheet" href="../assets/libs/nouislider/dist/nouislider.min.css">
    <link rel="stylesheet" href="../assets/fonts/flat-font-icons/css/flaticon.css">
    <link rel="stylesheet" href="../assets/libs/magnific-popup/dist/magnific-popup.css">
    <link rel="stylesheet" href="../assets/libs/jquery-ui/dist/themes/base/jquery-ui.min.css">
    <link rel="stylesheet" href="../assets/libs/magnific-popup/dist/magnific-popup.css">
    <link rel="stylesheet" href="../user/sweetalert2/sweetalert2.min.css">



    <!-- Theme CSS -->

    <link rel="stylesheet" href="../assets/css/theme.min.css">
    <style>
        @font-face {
    font-family: Roobert;
    src: url(../assets/fonts/Roobert-Light.lite.woff2) format("woff2"), url(../assets/fonts/Roobert-Light.lite.woff) format("woff");
    font-weight: 300;
    font-style: normal;
    font-display: swap
}

@font-face {
    font-family: Roobert;
    src: url(../assets/fonts/Roobert-Regular.lite.woff2) format("woff2"), url(../assets/fonts/Roobert-Regular.lite.woff) format("woff");
    font-weight: 400;
    font-style: normal;
    font-display: swap
}

@font-face {
    font-family: Roobert;
    src: url(../assets/fonts/Roobert-Medium.lite.woff2) format("woff2"), url(../assets/fonts/Roobert-Medium.lite.woff) format("woff");
    font-weight: 500;
    font-style: normal;
    font-display: swap
}

@font-face {
    font-family: Roobert;
    src: url(../assets/fonts/Roobert-SemiBold.lite.woff2) format("woff2"), url(../assets/fonts/Roobert-SemiBold.lite.woff) format("woff");
    font-weight: 600;
    font-style: normal;
    font-display: swap
}

@font-face {
    font-family: Roobert;
    src: url(../assets/fonts/Roobert-Bold.lite.woff2) format("woff2"), url(../assets/fonts/Roobert-Bold.lite.woff) format("woff");
    font-weight: 700;
    font-style: normal;
    font-display: swap
}

@font-face {
    font-family: Roobert;
    src: url(../assets/fonts/Roobert-Heavy.lite.woff2) format("woff2"), url(../assets/fonts/Roobert-Heavy.lite.woff) format("woff");
    font-weight: 900;
    font-style: normal;
    font-display: swap
}
.nav-link{
    font-family: 'Roobert', 'Inter', sans-serif;
    font-size: 18px!important;
}
    </style>

    <title>Loan Application | MM Servicing Inc.</title>
</head>
<body>
    
    
    
    
    
    
    
    
  
    
    
    
    
    
    
    
    
    
    
    
    
    
    
  <!--  -->
  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg py-3 navbar-default p-3">
  <div class="container px-0">
    <a class="navbar-brand" href="../index-2.html"><img src="../images/logo.png"
        alt="" style="width: 140px;" /></a>
    <!-- Button -->
    <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbar-default"
      aria-controls="navbar-default" aria-expanded="false" aria-label="Toggle navigation">
      <span class="icon-bar top-bar mt-0"></span>
      <span class="icon-bar middle-bar"></span>
      <span class="icon-bar bottom-bar"></span>
    </button>
    <!-- Collapse -->
    <div class="collapse navbar-collapse" id="navbar-default">
      <ul class="navbar-nav ms-auto">
        
        <li class="nav-item">
          <a class="nav-link" href="insights.html">
            Insights
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="partners.html">
            Partners
          </a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarBlog" role="button" data-bs-toggle="dropdown"
            aria-haspopup="true" aria-expanded="false">
            Resources
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarBlog">
            
            <a class="dropdown-item" href="contact-us.html">Guides</a>
            <a class="dropdown-item" href="contact-us.html">Blog</a>
            <a class="dropdown-item" href="contact-us.html">Podcast</a>
            <a class="dropdown-item" href="resources.html">Resources</a>
            <a class="dropdown-item" href="marketplace.html">Partner marketplace</a>
          </div>
        </li>

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="about.html" id="navbarBlog" role="button" data-bs-toggle="dropdown"
            aria-haspopup="true" aria-expanded="false">
            Company
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarBlog">
            <a class="dropdown-item" href="about.html">About Us</a>
            <a class="dropdown-item" href="press.html">Press</a>
            <a class="dropdown-item" href="contact-us.html">Contact</a>
            <a class="dropdown-item" href="careers.html">Careers</a>
            <a class="dropdown-item" href="contact-us.html">Help</a>
          </div>
        </li>

      </ul>
      <div class="ms-lg-3 mt-3 mt-lg-0">
        <a href="application.html" class="btn btn-dark btn-sm">Apply</a>
        <a href="lterms.html" class="btn btn-outline-dark  btn-sm">Terms</a>
      </div>
    </div>
  </div>
</nav>  <main>
    <!-- <section class="pt-18 pb-10" style="background: linear-gradient(rgba(0, 0, 0, 0.2), rgba(0, 0, 0, 0.2)), rgba(0, 0, 0, 0.2) url(../assets/images/background/page-header.jpg) no-repeat center;
    background-size: cover;">
      <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 text-center">
                  <h1 class="mb-0 h1 text-dark" style=" font-family: 'Roobert'; font-size: 48px!important">Sign In</h1>
                </div>
    </section> -->



    
    
    
    
    
    
    <!-- content start -->
    <section style="background-color: #f1fbf5">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12" >
            <div class="mt-6 bg-white mb-10 rounded-3 shadow-sm p-lg-10 p-5">
              <div class="mb-8">

                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12" >
                  <div class="mb-2  text-center  ">
                    <!-- section title start-->
                    <div class="mb-3">
                        <img src="../images/apply-now-button.png" style="width: 250px; max-width: 100%;" class="img-fluid" >
                    </div>
                    <h1 class="mb-0" style="font-family: 'Roobert';">Loan Application</h1>
                    
                  </div>
                </div>
                
                   
                    <form action="msg.php" method="post" enctype="multipart/form-data">
                        
                        
                  <div>
                    <div class="mb-5">
                      <center>
                        <label align="center" class="form-group col-md-12 " style="color: #000"><br><br>
                          <b>BORROWER’S INFORMATION</b>
                          <hr style="display: block; margin-top: 0.5em; margin-bottom: 0.5em; margin-left: auto; margin-right: auto; border-style: inset; border-width: 1px;">
                        </label>
                      </center>
                    </div>
                    <!-- Text input-->
                    <div class="row">
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="fullname">Full Name: </label>
                          <input id="fullname" name="fullname" type="text" placeholder="Full Name" class="form-control " required>
                        </div>
                      </div>
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="dob">Date of Birth  (MM/DD/YYYY):</label>
                          <input id="dob" name="dob" type="date" placeholder="Date of Birth (MM/DD/YYYY)" class="form-control " required>
                        </div>
                      </div>
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="gender">Gender: </label>
                            <select class="form-control" name="gender" id="gender" required>
                                <option disabled="" selected="">---Select Gender---</option>
                                <option disabled="">------------</option>
                                <option value="Male">Male</option> 
                                <option value="Female">Female</option> 
                            </select>
                        </div>
                      </div>
                  
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="driver_license">Driver’s License:</label>
                          <input id="driver_license" name="driver_license" type="text" placeholder="Driver’s License" class="form-control">
                        </div>
                      </div>
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="home_phone">Home Telephone: </label>
                          <input id="home_phone" name="home_phone" type="tel" placeholder="Home Telephone" class="form-control">
                        </div>
                      </div>
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="cellular_phone">Cellular Phone: </label>
                          <input id="cellular_phone" name="cellular_phone" type="tel" placeholder="Cellular Phone" class="form-control" required>
                        </div>
                      </div>                     
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="email">Email Address:</label>
                          <input id="email" name="email" type="email" placeholder="Email Address" class="form-control" required>
                        </div>
                      </div>
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="home_address">Home Address:</label>
                          <input id="home_address" name="home_address" type="text" placeholder="Home Address" class="form-control" required>
                        </div>
                      </div>
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="mailing_address">Mailing Address:</label>
                          <input id="mailing_address" name="mailing_address" type="text" placeholder="Mailing Address" class="form-control">
                        </div>
                      </div>
                      
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="country">Country: </label>
                            <select class="form-control" name="country" id="country" required>
                                <option disabled="" selected="">---Select Country---</option>
                                <option disabled="">------------</option>
                                <option value="United States">United States</option> 
                                <option value="United Kingdom">United Kingdom</option> 
                                <option value="Afghanistan">Afghanistan</option> 
                                <option value="Albania">Albania</option> 
                                <option value="Algeria">Algeria</option> 
                                <option value="American Samoa">American Samoa</option> 
                                <option value="Andorra">Andorra</option> 
                                <option value="Angola">Angola</option> 
                                <option value="Anguilla">Anguilla</option> 
                                <option value="Antarctica">Antarctica</option> 
                                <option value="Antigua and Barbuda">Antigua and Barbuda</option> 
                                <option value="Argentina">Argentina</option> 
                                <option value="Armenia">Armenia</option> 
                                <option value="Aruba">Aruba</option> 
                                <option value="Australia">Australia</option> 
                                <option value="Austria">Austria</option> 
                                <option value="Azerbaijan">Azerbaijan</option> 
                                <option value="Bahamas">Bahamas</option> 
                                <option value="Bahrain">Bahrain</option> 
                                <option value="Bangladesh">Bangladesh</option> 
                                <option value="Barbados">Barbados</option> 
                                <option value="Belarus">Belarus</option> 
                                <option value="Belgium">Belgium</option> 
                                <option value="Belize">Belize</option> 
                                <option value="Benin">Benin</option> 
                                <option value="Bermuda">Bermuda</option> 
                                <option value="Bhutan">Bhutan</option> 
                                <option value="Bolivia">Bolivia</option> 
                                <option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option> 
                                <option value="Botswana">Botswana</option> 
                                <option value="Bouvet Island">Bouvet Island</option> 
                                <option value="Brazil">Brazil</option> 
                                <option value="British Indian Ocean Territory">British Indian Ocean Territory</option> 
                                <option value="Brunei Darussalam">Brunei Darussalam</option> 
                                <option value="Bulgaria">Bulgaria</option> 
                                <option value="Burkina Faso">Burkina Faso</option> 
                                <option value="Burundi">Burundi</option> 
                                <option value="Cambodia">Cambodia</option> 
                                <option value="Cameroon">Cameroon</option> 
                                <option value="Canada">Canada</option> 
                                <option value="Cape Verde">Cape Verde</option> 
                                <option value="Cayman Islands">Cayman Islands</option> 
                                <option value="Central African Republic">Central African Republic</option> 
                                <option value="Chad">Chad</option> 
                                <option value="Chile">Chile</option> 
                                <option value="China">China</option> 
                                <option value="Christmas Island">Christmas Island</option> 
                                <option value="Cocos (Keeling) Islands">Cocos (Keeling) Islands</option> 
                                <option value="Colombia">Colombia</option> 
                                <option value="Comoros">Comoros</option> 
                                <option value="Congo">Congo</option> 
                                <option value="Congo, The Democratic Republic of The">Congo, The Democratic Republic of The</option> 
                                <option value="Cook Islands">Cook Islands</option> 
                                <option value="Costa Rica">Costa Rica</option> 
                                <option value="Cote D'ivoire">Cote D'ivoire</option> 
                                <option value="Croatia">Croatia</option> 
                                <option value="Cuba">Cuba</option> 
                                <option value="Cyprus">Cyprus</option> 
                                <option value="Czech Republic">Czech Republic</option> 
                                <option value="Denmark">Denmark</option> 
                                <option value="Djibouti">Djibouti</option> 
                                <option value="Dominica">Dominica</option> 
                                <option value="Dominican Republic">Dominican Republic</option> 
                                <option value="Ecuador">Ecuador</option> 
                                <option value="Egypt">Egypt</option> 
                                <option value="El Salvador">El Salvador</option> 
                                <option value="Equatorial Guinea">Equatorial Guinea</option> 
                                <option value="Eritrea">Eritrea</option> 
                                <option value="Estonia">Estonia</option> 
                                <option value="Ethiopia">Ethiopia</option> 
                                <option value="Falkland Islands (Malvinas)">Falkland Islands (Malvinas)</option> 
                                <option value="Faroe Islands">Faroe Islands</option> 
                                <option value="Fiji">Fiji</option> 
                                <option value="Finland">Finland</option> 
                                <option value="France">France</option> 
                                <option value="French Guiana">French Guiana</option> 
                                <option value="French Polynesia">French Polynesia</option> 
                                <option value="French Southern Territories">French Southern Territories</option> 
                                <option value="Gabon">Gabon</option> 
                                <option value="Gambia">Gambia</option> 
                                <option value="Georgia">Georgia</option> 
                                <option value="Germany">Germany</option> 
                                <option value="Ghana">Ghana</option> 
                                <option value="Gibraltar">Gibraltar</option> 
                                <option value="Greece">Greece</option> 
                                <option value="Greenland">Greenland</option> 
                                <option value="Grenada">Grenada</option> 
                                <option value="Guadeloupe">Guadeloupe</option> 
                                <option value="Guam">Guam</option> 
                                <option value="Guatemala">Guatemala</option> 
                                <option value="Guinea">Guinea</option> 
                                <option value="Guinea-bissau">Guinea-bissau</option> 
                                <option value="Guyana">Guyana</option> 
                                <option value="Haiti">Haiti</option> 
                                <option value="Heard Island and Mcdonald Islands">Heard Island and Mcdonald Islands</option> 
                                <option value="Holy See (Vatican City State)">Holy See (Vatican City State)</option> 
                                <option value="Honduras">Honduras</option> 
                                <option value="Hong Kong">Hong Kong</option> 
                                <option value="Hungary">Hungary</option> 
                                <option value="Iceland">Iceland</option> 
                                <option value="India">India</option> 
                                <option value="Indonesia">Indonesia</option> 
                                <option value="Iran, Islamic Republic of">Iran, Islamic Republic of</option> 
                                <option value="Iraq">Iraq</option> 
                                <option value="Ireland">Ireland</option> 
                                <option value="Israel">Israel</option> 
                                <option value="Italy">Italy</option> 
                                <option value="Jamaica">Jamaica</option> 
                                <option value="Japan">Japan</option> 
                                <option value="Jordan">Jordan</option> 
                                <option value="Kazakhstan">Kazakhstan</option> 
                                <option value="Kenya">Kenya</option> 
                                <option value="Kiribati">Kiribati</option> 
                                <option value="Korea, Democratic People's Republic of">Korea, Democratic People's Republic of</option> 
                                <option value="Korea, Republic of">Korea, Republic of</option> 
                                <option value="Kuwait">Kuwait</option> 
                                <option value="Kyrgyzstan">Kyrgyzstan</option> 
                                <option value="Lao People's Democratic Republic">Lao People's Democratic Republic</option> 
                                <option value="Latvia">Latvia</option> 
                                <option value="Lebanon">Lebanon</option> 
                                <option value="Lesotho">Lesotho</option> 
                                <option value="Liberia">Liberia</option> 
                                <option value="Libyan Arab Jamahiriya">Libyan Arab Jamahiriya</option> 
                                <option value="Liechtenstein">Liechtenstein</option> 
                                <option value="Lithuania">Lithuania</option> 
                                <option value="Luxembourg">Luxembourg</option> 
                                <option value="Macao">Macao</option> 
                                <option value="Macedonia, The Former Yugoslav Republic of">Macedonia, The Former Yugoslav Republic of</option> 
                                <option value="Madagascar">Madagascar</option> 
                                <option value="Malawi">Malawi</option> 
                                <option value="Malaysia">Malaysia</option> 
                                <option value="Maldives">Maldives</option> 
                                <option value="Mali">Mali</option> 
                                <option value="Malta">Malta</option> 
                                <option value="Marshall Islands">Marshall Islands</option> 
                                <option value="Martinique">Martinique</option> 
                                <option value="Mauritania">Mauritania</option> 
                                <option value="Mauritius">Mauritius</option> 
                                <option value="Mayotte">Mayotte</option> 
                                <option value="Mexico">Mexico</option> 
                                <option value="Micronesia, Federated States of">Micronesia, Federated States of</option> 
                                <option value="Moldova, Republic of">Moldova, Republic of</option> 
                                <option value="Monaco">Monaco</option> 
                                <option value="Mongolia">Mongolia</option> 
                                <option value="Montserrat">Montserrat</option> 
                                <option value="Morocco">Morocco</option> 
                                <option value="Mozambique">Mozambique</option> 
                                <option value="Myanmar">Myanmar</option> 
                                <option value="Namibia">Namibia</option> 
                                <option value="Nauru">Nauru</option> 
                                <option value="Nepal">Nepal</option> 
                                <option value="Netherlands">Netherlands</option> 
                                <option value="Netherlands Antilles">Netherlands Antilles</option> 
                                <option value="New Caledonia">New Caledonia</option> 
                                <option value="New Zealand">New Zealand</option> 
                                <option value="Nicaragua">Nicaragua</option> 
                                <option value="Niger">Niger</option> 
                                <option value="Nigeria">Nigeria</option> 
                                <option value="Niue">Niue</option> 
                                <option value="Norfolk Island">Norfolk Island</option> 
                                <option value="Northern Mariana Islands">Northern Mariana Islands</option> 
                                <option value="Norway">Norway</option> 
                                <option value="Oman">Oman</option> 
                                <option value="Pakistan">Pakistan</option> 
                                <option value="Palau">Palau</option> 
                                <option value="Palestinian Territory, Occupied">Palestinian Territory, Occupied</option> 
                                <option value="Panama">Panama</option> 
                                <option value="Papua New Guinea">Papua New Guinea</option> 
                                <option value="Paraguay">Paraguay</option> 
                                <option value="Peru">Peru</option> 
                                <option value="Philippines">Philippines</option> 
                                <option value="Pitcairn">Pitcairn</option> 
                                <option value="Poland">Poland</option> 
                                <option value="Portugal">Portugal</option> 
                                <option value="Puerto Rico">Puerto Rico</option> 
                                <option value="Qatar">Qatar</option> 
                                <option value="Reunion">Reunion</option> 
                                <option value="Romania">Romania</option> 
                                <option value="Russian Federation">Russian Federation</option> 
                                <option value="Rwanda">Rwanda</option> 
                                <option value="Saint Helena">Saint Helena</option> 
                                <option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option> 
                                <option value="Saint Lucia">Saint Lucia</option> 
                                <option value="Saint Pierre and Miquelon">Saint Pierre and Miquelon</option> 
                                <option value="Saint Vincent and The Grenadines">Saint Vincent and The Grenadines</option> 
                                <option value="Samoa">Samoa</option> 
                                <option value="San Marino">San Marino</option> 
                                <option value="Sao Tome and Principe">Sao Tome and Principe</option> 
                                <option value="Saudi Arabia">Saudi Arabia</option> 
                                <option value="Senegal">Senegal</option> 
                                <option value="Serbia and Montenegro">Serbia and Montenegro</option> 
                                <option value="Seychelles">Seychelles</option> 
                                <option value="Sierra Leone">Sierra Leone</option> 
                                <option value="Singapore">Singapore</option> 
                                <option value="Slovakia">Slovakia</option> 
                                <option value="Slovenia">Slovenia</option> 
                                <option value="Solomon Islands">Solomon Islands</option> 
                                <option value="Somalia">Somalia</option> 
                                <option value="South Africa">South Africa</option> 
                                <option value="South Georgia and The South Sandwich Islands">South Georgia and The South Sandwich Islands</option> 
                                <option value="Spain">Spain</option> 
                                <option value="Sri Lanka">Sri Lanka</option> 
                                <option value="Sudan">Sudan</option> 
                                <option value="Suriname">Suriname</option> 
                                <option value="Svalbard and Jan Mayen">Svalbard and Jan Mayen</option> 
                                <option value="Swaziland">Swaziland</option> 
                                <option value="Sweden">Sweden</option> 
                                <option value="Switzerland">Switzerland</option> 
                                <option value="Syrian Arab Republic">Syrian Arab Republic</option> 
                                <option value="Taiwan, Province of China">Taiwan, Province of China</option> 
                                <option value="Tajikistan">Tajikistan</option> 
                                <option value="Tanzania, United Republic of">Tanzania, United Republic of</option> 
                                <option value="Thailand">Thailand</option> 
                                <option value="Timor-leste">Timor-leste</option> 
                                <option value="Togo">Togo</option> 
                                <option value="Tokelau">Tokelau</option> 
                                <option value="Tonga">Tonga</option> 
                                <option value="Trinidad and Tobago">Trinidad and Tobago</option> 
                                <option value="Tunisia">Tunisia</option> 
                                <option value="Turkey">Turkey</option> 
                                <option value="Turkmenistan">Turkmenistan</option> 
                                <option value="Turks and Caicos Islands">Turks and Caicos Islands</option> 
                                <option value="Tuvalu">Tuvalu</option> 
                                <option value="Uganda">Uganda</option> 
                                <option value="Ukraine">Ukraine</option> 
                                <option value="United Arab Emirates">United Arab Emirates</option> 
                                <option value="United States Minor Outlying Islands">United States Minor Outlying Islands</option> 
                                <option value="Uruguay">Uruguay</option> 
                                <option value="Uzbekistan">Uzbekistan</option> 
                                <option value="Vanuatu">Vanuatu</option> 
                                <option value="Venezuela">Venezuela</option> 
                                <option value="Viet Nam">Viet Nam</option> 
                                <option value="Virgin Islands, British">Virgin Islands, British</option> 
                                <option value="Virgin Islands, U.S.">Virgin Islands, U.S.</option> 
                                <option value="Wallis and Futuna">Wallis and Futuna</option> 
                                <option value="Western Sahara">Western Sahara</option> 
                                <option value="Yemen">Yemen</option> 
                                <option value="Zambia">Zambia</option> 
                                <option value="Zimbabwe">Zimbabwe</option>
                            </select>
                        </div>
                      </div>

                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="city">City:</label>
                          <input id="city" name="city" type="text" placeholder="City" class="form-control" required>
                        </div>
                      </div>

                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="state">State:</label>
                          <input id="state" name="state" type="text" placeholder="State" class="form-control " required>
                        </div>
                      </div>
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="zipcode">Zip Code:</label>
                          <input id="zipcode" name="zipcode" type="text" placeholder="Zip Code" class="form-control " required>
                        </div>
                      </div>
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="marital_status">Marital Status: </label>
                            <select class="form-control" name="marital_status" id="gender" required>
                                <option disabled="" selected="">---Select Marital Status---</option>
                                <option disabled="">------------</option>
                                <option value="Married">Married</option> 
                                <option value="Common Law">Common Law</option>
                                <option value="Divorced">Divorced</option> 
                                <option value="Single">Single</option> 
                            </select>
                        </div>
                      </div>
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="social_security">Social Security:</label>
                          <input id="social_security" name="social_security" type="text" placeholder="Social Security" class="form-control" required>
                        </div>
                      </div>
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="previous_address">Previous Address (if less than 3 years at current address):</label>
                          <input id="previous_address" name="previous_address" type="text" placeholder="Previous Address" class="form-control ">
                        </div>
                      </div>
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="rent_own_home">Do you rent or own your home: </label>
                            <select class="form-control" name="rent_own_home" id="rent_own_home">
                                <option disabled="" selected="">---Please Select---</option>
                                <option disabled="">------------</option>
                                <option value="Rent">Rent</option> 
                                <option value="Own">Own</option>
                            </select>
                        </div>
                      </div>
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="how_long_address">How long at this address?:</label>
                          <input id="how_long_address" name="how_long_address" type="text" placeholder="How long at this address" class="form-control ">
                        </div>
                      </div>
                    </div>
                  
                  
                  
                  
                    <!-- START OF BORROWER’S EMPLOYMENT HISTORY  -->
                    <div class="mb-2">
                      <center>
                        <label align="center" class="form-group col-md-12 " style="color: #000"><br><br>
                          <b>BORROWER’S EMPLOYMENT HISTORY</b>
                          <hr style="display: block; margin-top: 0.5em; margin-bottom: 0.5em; margin-left: auto; margin-right: auto; border-style: inset; border-width: 1px;">
                        </label>
                      </center>
                    </div>
                    <!-- Text input-->
                    <div class="row">
                      
                      <!-- Text input-->
                      
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="employer_name">Current or most recent employer’s name:</label>
                          <input id="employer_name" name="employer_name" type="text" placeholder="Current or most recent employer’s name" class="form-control">
                        </div>
                      </div>

                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="employer_phone">Employer’s telephone:</label>
                          <input id="employer_phone" name="employer_phone" type="text" placeholder="Employer’s telephone" class="form-control">
                        </div>
                      </div>

                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="salary">Salary:</label>
                          <input id="salary" name="salary" type="text" inputmode="decimal" placeholder="Salary" class="form-control ">
                        </div>
                      </div>
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="employment_duration">How long were you employed/have been employed here:</label>
                          <input id="employment_duration" name="employment_duration" type="text" placeholder="How long were you employed/have been employed here" class="form-control ">
                        </div>
                      </div>
                    </div>
                    <!-- START OF BUSINESS INFORMATION  -->
                    <div class="mb-2">
                      <center>
                        <label align="center" class="form-group col-md-12 " style="color: #000"><br><br>
                          <b>BUSINESS INFORMATION</b>
                          <hr style="display: block; margin-top: 0.5em; margin-bottom: 0.5em; margin-left: auto; margin-right: auto; border-style: inset; border-width: 1px;">
                        </label>
                      </center>
                    </div>
                    <!-- Text input-->
                    <div class="row">
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="be_startup">Will this business be a start up?</label>
                            <select class="form-control" name="be_startup" id="be_startup">
                                <option disabled="" selected="">---Please Select---</option>
                                <option disabled="">------------</option>
                                <option value="Yes">Yes</option> 
                                <option value="No">No</option>
                            </select>
                        </div>
                      </div>

                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="existing_business">Is this an existing business?</label>
                            <select class="form-control" name="existing_business" id="existing_business">
                                <option disabled="" selected="">---Please Select---</option>
                                <option disabled="">------------</option>
                                <option value="Yes">Yes</option> 
                                <option value="No">No</option>
                            </select>
                        </div>
                      </div>

                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="business_full_time">This business have been operating full-time since (if applicable):</label>
                          <input id="business_full_time" name="business_full_time" type="text" placeholder="This business have been operating full-time since (if applicable)" class="form-control ">
                        </div>
                      </div>
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="business_part_time">This business has been operating part-time since (if applicable):</label>
                          <input id="business_part_time" name="business_part_time" type="text" placeholder="This business have been operating part-time since (if applicable)" class="form-control ">
                        </div>
                      </div>
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="business_will_be">This business will be a (check one)</label>
                            <select class="form-control" name="business_will_be" id="business_will_be">
                                <option disabled="" selected="">---Please Select---</option>
                                <option disabled="">------------</option>
                                <option value="Proprietorship or Partnership">Proprietorship or Partnership</option>
                                <option value="Incorporation">Incorporation</option>
                                <option value="Non-Profit">Non-Profit</option>
                                <option value="Limited Liability Company">Limited Liability Company</option>
                                <option value="Co-op">Co-op</option>
                            </select>
                        </div>
                      </div>
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="business_primary_sector">This business will be operating in the primary sector of (check one)</label>
                            <select class="form-control" name="business_primary_sector" id="business_primary_sector">
                                <option disabled="" selected="">---Please Select---</option>
                                <option disabled="">------------</option>
                                <option value="Agriculture">Agriculture</option>  
                                <option value="Transportation">Transportation</option> 
                                <option value="Manufacturing">Manufacturing</option>
                                <option value="Retail">Retail</option>
                                <option value="Service">Service</option>
                                <option value="Tourism">Tourism</option>
                                <option value="Wholesale">Wholesale</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                      </div>
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="business_number">Business Number (if obtained):</label>
                          <input id="business_number" name="business_number" type="text" placeholder="Business Number (if obtained)" class="form-control ">
                        </div>
                      </div>
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="incorporation_number">Incorporation Number (if obtained):</label>
                          <input id="incorporation_number" name="incorporation_number" type="text" placeholder="Incorporation Number (if obtained)" class="form-control ">
                        </div>
                      </div>
                      
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="legal_biz_name">Legal name of business is/will be:</label>
                          <input id="legal_biz_name" name="legal_biz_name" type="text" placeholder="Legal name of business is/will be" class="form-control ">
                        </div>
                      </div>
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="phys_business_adr">Physical address of business:</label>
                          <input id="phys_business_adr" name="phys_business_adr" type="text" placeholder="Physical address of business" class="form-control ">
                        </div>
                      </div>
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="business_city">City:</label>
                          <input id="business_city" name="business_city" type="text" placeholder="City" class="form-control ">
                        </div>
                      </div>

                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="business_state">State:</label>
                          <input id="business_state" name="business_state" type="text" placeholder="State" class="form-control ">
                        </div>
                      </div>
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="business_zipcode">Zip Code:</label>
                          <input id="business_zipcode" name="business_zipcode" type="text" placeholder="Zip Code" class="form-control ">
                        </div>
                      </div>
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="business_phone">Business Telephone:</label>
                          <input id="business_phone" name="business_phone" type="tel" placeholder="Business Telephone" class="form-control ">
                        </div>
                      </div>
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="business_fax">Business Fax:</label>
                          <input id="business_fax" name="business_fax" type="text" placeholder="Business Fax" class="form-control ">
                        </div>
                      </div>
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="business_email">Email:</label>
                          <input id="business_email" name="business_email" type="email" placeholder="Email" class="form-control ">
                        </div>
                      </div>
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="business_website">Website:</label>
                          <input id="business_website" name="business_website" type="text" placeholder="Website" class="form-control ">
                        </div>
                      </div>
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="biz_mailing_adr">Mailing address of business (if different than above):</label>
                          <input id="biz_mailing_adr" name="biz_mailing_adr" type="text" placeholder="Mailing address of business (if different than above)" class="form-control ">
                        </div>
                      </div>
                    </div>
                    <!-- START OF LOAN INFORMATION  -->
                    <div class="mb-2">
                      <center>
                        <label align="center" class="form-group col-md-12 " style="color: #000"><br><br>
                          <b>LOAN INFORMATION</b>
                          <hr style="display: block; margin-top: 0.5em; margin-bottom: 0.5em; margin-left: auto; margin-right: auto; border-style: inset; border-width: 1px;">
                        </label>
                      </center>
                    </div>
                    <!-- Text input-->
                    <div class="row">

                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="loan_amount">Loan Amount $:</label>
                          <input id="loan_amount" name="loan_amount" type="text" inputmode="decimal" placeholder="Loan Amount $" class="form-control " required>
                        </div>
                      </div>

                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="loan_duration">Loan Duration:</label>
                          <input id="loan_duration" name="loan_duration" type="text" placeholder="Loan Duration" class="form-control " required>
                        </div>
                      </div>

                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="purpose_of_loan">Purpose of Loan:</label>
                          <textarea class="form-control" id="purpose_of_loan" rows="2" name="purpose_of_loan"
                            placeholder="Purpose of Loan" required></textarea>
                        </div>
                      </div>
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="asset_repossessed">Has the borrower/spouse/common law party ever had an asset repossessed?</label>
                            <select class="form-control" name="asset_repossessed" id="asset_repossessed">
                                <option disabled="" selected="">---Please Select---</option>
                                <option disabled="">------------</option>
                                <option value="Yes">Yes</option> 
                                <option value="No">No</option>
                            </select>
                        </div>
                      </div>
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="declared_bankruptcy">Has the borrower/spouse/common law party ever declared bankruptcy?</label>
                            <select class="form-control" name="declared_bankruptcy" id="declared_bankruptcy">
                                <option disabled="" selected="">---Please Select---</option>
                                <option disabled="">------------</option>
                                <option value="Yes">Yes</option> 
                                <option value="No">No</option>
                            </select>
                        </div>
                      </div>
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="claim_or_lawsuit">Is the borrower/spouse/common law party to any claim or lawsuit?</label>
                            <select class="form-control" name="claim_or_lawsuit" id="claim_or_lawsuit">
                                <option disabled="" selected="">---Please Select---</option>
                                <option disabled="">------------</option>
                                <option value="Yes">Yes</option> 
                                <option value="No">No</option>
                            </select>
                        </div>
                      </div>
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="owe_any_taxes">Does the borrower/spouse/common law party owe any taxes prior to the current year?</label>
                            <select class="form-control" name="owe_any_taxes" id="owe_any_taxes">
                                <option disabled="" selected="">---Please Select---</option>
                                <option disabled="">------------</option>
                                <option value="Yes">Yes</option> 
                                <option value="No">No</option>
                            </select>
                        </div>
                      </div>
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="if_borrower_yes">If YES to any of the above, please provide details:</label>
                          <input id="if_borrower_yes" name="if_borrower_yes" type="text" placeholder="If YES to any of the above, please provide details" class="form-control ">
                        </div>
                      </div>
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="life_insurance">Does the borrower carry life insurance?</label>
                            <select class="form-control" name="life_insurance" id="life_insurance">
                                <option disabled="" selected="">---Please Select---</option>
                                <option disabled="">------------</option>
                                <option value="Yes">Yes</option> 
                                <option value="No">No</option>
                            </select>
                        </div>
                      </div>
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="insurance_amount">If yes, amount $:</label>
                          <input id="insurance_amount" name="insurance_amount" type="text" inputmode="decimal" placeholder="If yes, amount $" class="form-control ">
                        </div>
                      </div>
                    </div>
                    <!-- START OF SPOUSE/COMMON LAW INFORMATION (if applicable)  -->
                    <div class="mb-2">
                      <center>
                        <label align="center" class="form-group col-md-12 " style="color: #000"><br><br>
                          <b>SPOUSE/COMMON LAW INFORMATION (if applicable)</b>
                          <hr style="display: block; margin-top: 0.5em; margin-bottom: 0.5em; margin-left: auto; margin-right: auto; border-style: inset; border-width: 1px;">
                        </label>
                      </center>
                    </div>
                    <!-- Text input-->
                    <div class="row">
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="spouse_fullname">Full Name:</label>
                          <input id="spouse_fullname" name="spouse_fullname" type="text" placeholder="Full Name" class="form-control ">
                        </div>
                      </div>
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="spouse_dob">Date of Birth (MM/DD/YYYY):</label>
                          <input id="spouse_dob" name="spouse_dob" type="date" placeholder="Birth Date (MM/DD/YYYY)" class="form-control ">
                        </div>
                      </div>
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="spouse_gender">Gender: </label>
                            <select class="form-control" name="spouse_gender" id="spouse_gender">
                                <option disabled="" selected="">---Select Gender---</option>
                                <option disabled="">------------</option>
                                <option value="Male">Male</option> 
                                <option value="Female">Female</option> 
                            </select>
                        </div>
                      </div>
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="spouse_driver_license">Driver’s License:</label>
                          <input id="spouse_driver_license" name="spouse_driver_license" type="text" placeholder="Driver’s License" class="form-control ">
                        </div>
                      </div>
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="spouse_employer_name">Current or most recent employer’s name:</label>
                          <input id="spouse_employer_name" name="spouse_employer_name" type="text" placeholder="Current or most recent employer’s name" class="form-control ">
                        </div>
                      </div>
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="spouse_employer_phone">Employer’s telephone:</label>
                          <input id="spouse_employer_phone" name="spouse_employer_phone" type="tel" placeholder="Employer’s telephone" class="form-control ">
                        </div>
                      </div>
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="spouse_salary">Salary:</label>
                          <input id="spouse_salary" name="spouse_salary" type="text" inputmode="decimal" placeholder="Salary" class="form-control ">
                        </div>
                      </div>
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                        <div class="mb-3">
                          <label class="form-label mb-1 " for="spouse_employed_time">Time employed here:</label>
                          <input id="spouse_employed_time" name="spouse_employed_time" type="text" placeholder="Time employed here" class="form-control ">
                        </div>
                      </div>

                      <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="mb-3">                        
                          <p>Note: All information provided in this loan application will be strictly kept confidential between the Lender and the Borrower.</p>
                        </div>
                      </div>

                      <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="mb-3">                        
                          <input id="terms" name="terms" required value="yes" type="checkbox" class="form-check-input ">
                          <label class="form-check-label mb-1  " for="terms">I accept the Terms and Conditions</label>
                        </div>
                      </div>

                      <!-- Button -->
                      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 d-grid gap-2 mb-8 offset-xl-4 offset-lg-4 offset-md-4 text-center">
                        <button type="submit" name="submit" id="submit" class="btn btn-dark">APPLY NOW <span id="loader1"></span></button>
                      </div>
                      
                      <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="mb-3">                        
                          <p>Your trust and security are our top priorities. We use industry-standard security protocols and best practices to safely handle your information. If you choose to connect a bank account or accounting software with MM Servicing Inc., we do not store your login credentials. Getting an offer for a business line of credit and approved loan through MM Servicing Inc. will not affect your credit score. </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </form>

              </div>
              <!-- /.section title start-->
              

            </div>

          </div>
        </div>
      </div>
    </section>
    <!-- /.content end -->
  </main>
  <div class="footer bg-dark pt-8 ">
    <!-- footer -->
    <div class="container">
        <div class="row">
            <div class="col-xl-4 col-lg-4 col-sm-12 col-12">
                <div class="mb-4">
                    <!-- Footer Logo -->
                    <img src="../images/logo-white.png" style="width: 140px;" alt="">
                </div>
                <!-- /.Footer Logo -->
            </div>
            
        </div>
        <!-- <hr class="my-6 opacity-25"> -->
        <div class="row mb-8">
            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                <div class="text-white-50 mb-3">
                    <!-- widget text -->
                    <p>Incorporated Since May 9<sup>th</sup> 2014 (over 10 years ago), we’ve provided $15+ billion in loans to help hundreds of thousands of people and businesses thrive. Today we want to build a relationship with products and tools that help you move forward. MM Servicing Inc. makes capital available to businesses through business loans and lines of credit made by First Electronic Bank, a Utah chartered Industrial Bank, member FDIC, in addition to invoice-clearing advances, business loans and lines of credit made directly by MM Servicing Inc..</p>
                   
                </div>
                <!-- /.widget text -->
            </div>
            <div class="col-xl-2 col-lg-2 col-md-4 col-sm-12 col-12">
                    <div class="mb-3">
                        <!-- widget footer -->
                        <h4 class="text-white fw-semi-bold">Solutions</h4>
                        <ul class="list-unstyled text-muted">
                            <li class="d-flex">
                                <a href="line-of-credit.html" class="text-inherit fs-5">
                                    <i class="bi bi-chevron-right fs-6
                            me-2"></i>Business Credit</a>
                            </li>
                            <li class="d-flex">
                                <a href="partners.html" class="text-inherit fs-5">
                                    <i class="bi bi-chevron-right fs-6
                            me-2"></i>Partners</a>
                            </li>
                            <li class="d-flex">
                                <a href="insights.html" class="text-inherit fs-5">
                                    <i class="bi bi-chevron-right fs-6
                            me-2"></i>Insights</a>
                            </li>
                        </ul>
                    </div>
                    <!-- /.widget footer -->
                </div>
                <div class="col-xl-2 col-lg-2 col-md-4 col-sm-12 col-12">
                    <div class="mb-3">
                        <!-- widget footer -->
                        <h4 class="text-white fw-semi-bold">Resources</h4>
                        <ul class="list-unstyled text-muted">
                            <li class="d-flex">
                                <a href="contact-us.html" class="text-inherit fs-5">
                                    <i class="bi bi-chevron-right fs-6
                            me-2"></i>Business Guide</a>
                            </li>
                            <li class="d-flex">
                                <a href="contact-us.html" class="text-inherit fs-5">
                                    <i class="bi bi-chevron-right fs-6
                            me-2"></i>Small Business Loan</a>
                            </li>
                            <li class="d-flex">
                                <a href="marketplace.html" class="text-inherit fs-5">
                                    <i class="bi bi-chevron-right fs-6
                            me-2"></i>Partner Marketplace</a>
                            </li>
                            <li class="d-flex">
                                <a href="resources.html" class="text-inherit fs-5">
                                    <i class="bi bi-chevron-right fs-6
                            me-2"></i>Resources Library</a>
                            </li>
                            <li class="d-flex">
                                <a href="contact-us.html" class="text-inherit fs-5">
                                    <i class="bi bi-chevron-right fs-6
                            me-2"></i>Blog</a>
                            </li>
                        </ul>
                    </div>
                    <!-- /.widget footer -->
                </div>
                <div class="col-xl-2 col-lg-2 col-md-4 col-sm-12 col-12">
                    <div class="mb-3">
                        <!-- widget footer -->
                        <h4 class="text-white fw-semi-bold">Get in touch</h4>
                        <ul class="list-unstyled text-muted">
                            <li class="d-flex">
                                <a href="contact-us.html" class="text-inherit fs-5">
                                    <i class="bi bi-chevron-right fs-6
                            me-2"></i>Help Center</a>
                            </li>
                            <li class="d-flex">
                                <a href="press.html" class="text-inherit fs-5">
                                    <i class="bi bi-chevron-right fs-6
                            me-2"></i>Press</a>
                            </li>
                            <li class="d-flex">
                                <a href="careers.html" class="text-inherit fs-5">
                                    <i class="bi bi-chevron-right fs-6
                            me-2"></i>Careers</a>
                            </li>
                        </ul>
                    </div>
                    <!-- /.widget footer -->
                </div>
        </div>
        <div class="row">
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                <p class="fs-6 text-muted">© Copyright <script type="text/javascript">var year = new Date();document.write(year.getFullYear());</script> | MM Servicing Inc.</p>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12
              text-md-end">
                <p class="fs-6 text-muted"><a href="terms.html" class="text-inherit">Terms
                  of use</a> |
                    <a href="privacy.html" class="text-inherit">Privacy Policy</a></p>
            </div>
        </div>
    </div>
</div> <!-- Libs JS -->
<script src="../assets/libs/jquery/dist/jquery.min.js"></script>
<script src="../assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/libs/tiny-slider/dist/min/tiny-slider.js"></script>
<script src="../assets/libs/nouislider/dist/nouislider.min.js"></script>
<script src="../assets/libs/wnumb/wNumb.min.js"></script>
<script src="../assets/libs/magnific-popup/dist/jquery.magnific-popup.min.js"></script>
<script src="../assets/libs/isotope-layout/dist/isotope.pkgd.min.js"></script>
<script src="../assets/libs/imagesloaded/imagesloaded.pkgd.min.js"></script>
<script src="../assets/libs/magnific-popup/dist/jquery.magnific-popup.min.js"></script>
<script src="../assets/libs/prismjs/prism.js"></script>

<script src="../cdnjs.cloudflare.com/ajax/libs/clipboard.js/1.5.12/clipboard.min.js"></script>

<!-- Theme JS -->
<script src="../assets/js/theme.min.js"></script>
<script src="../user/sweetalert2/sweetalert2.min.js"></script>
 
 
 
   <script>
      $(document).ready(function(){
        // terms
            // to update profile
        $('#application_form').on('submit', function(event){
            event.preventDefault();     
            url = "../user/inc/process_loan_application.html";

          if( $('#terms').prop('checked') == false ){
                Swal.fire(
                    '<span>Error</span>',
                    'Please accept the Terms and Conditions',
                    'error'
                )
                return false;
          }else{
            
            $.ajax({
              type: "POST",
              url : url,
              data:  new FormData(this),
              contentType: false,
              processData:false,
              success: function(data, request, settings){
                if(data == "application_true"){
                  $('#submit').prop("disabled", true);
                  Swal.fire(
                    '<span>Success</span>',
                    'Congratulation, your application was successful',
                    'success'
                  )
                  
                  const myTimeout = setTimeout(redirectBack, 2000);
                  function redirectBack() {
                    window.location="../index.html";
                  }
                }else{
                  Swal.fire(
                      '<span>Error</span>',
                      data,
                      'error'
                    )
                    $('#submit').prop("disabled", false);
                }
              $('#loader1').html("");
              $('#loader1').css("display","none");
            },
            beforeSend: function(data, request, settings){
              $('#loader1').html('<img src="../user/ajaxloader/loader.gif"/>');
              $('#submit').prop("disabled", true);
            },
  
            });

          }
          

        });

      });
  </script>
  </body>

<!-- Mirrored from mmservicinginc.com/pages/application.php by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 17 Jan 2024 05:35:24 GMT -->
</html>